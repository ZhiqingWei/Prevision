(function($) {
  "use strict"; // Start of use strict

  // Smooth scrolling using jQuery easing
  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: (target.offset().top - 56)
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  // Closes responsive menu when a scroll trigger link is clicked
  $('.js-scroll-trigger').click(function() {
    $('.navbar-collapse').collapse('hide');
  });

  // Activate scrollspy to add active class to navbar items on scroll
  $('body').scrollspy({
    target: '#mainNav',
    offset: 56
  });
	
	
//Open url for each section of partners
	$('.navbar-brand js-scroll-trigger').click(function() {
		$('.back-button').display = "";
	});
	
	$('#CRP').click(function() {
		$('.container_s').html('<object data="https://www.climaterealityproject.org/"/>');
	}); 
	
	$('#FE').click(function() {
		$('.container_s').html('<object data="https://futureearth.org/"/>');
		//$('.back-button').style.visibility = "visible";
	});
	
	$('#YC').click(function() {
		$('.container_s').html('<object data="https://youthclimatemovement.wordpress.com/"/>');
	});
	
	$('#GN').click(function() {
		$('.container_s').html('<object data="https://www.globalnet21.org/"/>');
	});
	
	$('#SWT').click(function() {
		$('.container_s').html('<object data="https://www.surreywildlifetrust.org/support-us/become-member?gclid=Cj0KCQiA2ITuBRDkARIsAMK9Q7NHITcCz1pf7whnMUdEjCxLxCcEv0OS7f-blS32I_A0yExlJsv0wggaAh0kEALw_wcB"/>');
	}); 
	
	$('#GARP').click(function() {
		$('.container_s').html('<object data="https://www.garp.org/#!/home?utm_source=google&utm_medium=cpc&utm_campaign=f19exams%20%20GARP&utm_term=global%20association%20of%20risk%20professionals"/>');
	}); 
	
	$('#CP').click(function() {
		$('.container_s').html('<object data="https://www.coolplanet.com/"/>');
	}); 
	
	

	// Search Nav
//	$('.search-btn').on('click', function () {
//		$('.search-form').addClass('active');
//	});
//
//	$('.search-close').on('click', function () {
//		$('.search-form').removeClass('active');
//	});


})(jQuery); // End of use strict
